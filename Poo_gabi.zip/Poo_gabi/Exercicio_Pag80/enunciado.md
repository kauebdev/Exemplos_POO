
# Crie uma classe Produto para representar um produto do mundo real. 
Sua
classe deverá conter os seguintes atributos e métodos:
Um campo de dados privado chamado nome, que representará o nome do
produto. 2) Um campo de dados privado chamado precoCusto, que
guardará o preço de custo do produto. 3) Um campo de dados privado
chamado precoVenda, que guardará o preço de venda do produto. 4) Um
campo de dados privado chamado margemLucro, que guardará a margem
de lucro do produto. 5) Métodos públicos get() e set() para os atributos
acima. Modifique o método setPrecoVenda() para que o preço de venda
não seja inferior ao preço de compra. Caso isso aconteça, exiba uma
mensagem alertando o usuário. 6) Crie um método chamado
calcularMargemLucro() que calculará a margem de lucro do produto. 7)
Crie um método chamado getMargemLucroPorcentagem() que retornará a
margem de lucro como percentual.
Para finalizar, Crie uma página que interage com o usuário para que o
mesmo inserira o preço de custo e o preço de venda, crie um novo objeto
da classe Produto, e insira nos métodos getter e setter os valores
informados pelo usuário e exiba a margem de lucro em moeda e em
percentual. Sua saída deverá ser algo parecido com o mostrado na imagem
abaixo: