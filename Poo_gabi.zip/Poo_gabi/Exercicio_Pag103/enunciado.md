
# Exercício Polimorfismo
Crie uma página e as classes abaixo lembrando que a classe deve pegar
o valor de investimento, a quantidade de meses que ele quer
investir o valor e o tipo de investimento. Lembrando que a conta
poupança rende 0,7%=0,007 por mês e fundos simples de investimento
0,75% 0,0075.